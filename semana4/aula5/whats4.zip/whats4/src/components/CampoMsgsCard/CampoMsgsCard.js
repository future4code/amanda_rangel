import React from 'react'
import PropTypes from 'prop-types'
import styled from 'styled-components'

const CampoMsgsCardContainer = styled.div`

`

class CampoMsgsCard extends React.Component {
  constructor(props){
    super(props);
  }
    render(){
      return (
        <CampoMsgsCardContainer>
           
        </CampoMsgsCardContainer>
      );
    }
}

  CampoMsgsCard.propTypes = {
   
  }
  
export default CampoMsgsCard;